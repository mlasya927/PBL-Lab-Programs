// live date and time top right
function startClock() {
  updateClock();
  setInterval(updateClock, 1000);
  startFormTimer();
}

function updateClock() {
  const now = new Date();
  document.getElementById("clock").innerText = now.toLocaleDateString() + " " + now.toLocaleTimeString();
}

// alert if form takes more than 3 minutes
function startFormTimer() {
  setTimeout(function () {
    alert("3 mins past");
  }, 3 * 60 * 1000);
}

function validateForm() {
  const fname = document.getElementById("fname").value.trim();
  const lname = document.getElementById("lname").value.trim();
  const pwd = document.getElementById("pwd").value;
  const cpwd = document.getElementById("cpwd").value;
  const gender = document.querySelector('input[name="gender"]:checked');
  const mobile = document.getElementById("mobile").value.trim();
  const dob = document.getElementById("dob").value.trim();
  const email = document.getElementById("email").value.trim();

  const nameRegex = /^[A-Za-z]+$/;
  const mobileRegex = /^(\d{3}-\d{3}-\d{4}|\d{3}\.\d{3}\.\d{4}|\d{3} \d{3} \d{4})$/;
  const dobRegex = /^\d{2}-\d{2}-\d{4}$/;
  const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

  if (!fname) { alert("First name must be entered"); return false; }
  if (!nameRegex.test(fname)) { alert("First name must be character"); return false; }

  if (!lname) { alert("Last name must be entered"); return false; }
  if (!nameRegex.test(lname)) { alert("Last name must be character"); return false; }

  if (!pwd) { alert("Password must be entered"); return false; }
  if (pwd.length < 6 || pwd.length > 20) { alert("Password length should be between 6 to 20 characters"); return false; }

  if (!cpwd) { alert("Confirm password must be entered"); return false; }
  if (cpwd.length < 6 || cpwd.length > 20) { alert("Confirm password length should be between 6 to 20 characters"); return false; }

  if (pwd !== cpwd) { alert("Password and Confirm password should be same"); return false; }

  if (!gender) { alert("Gender must be selected"); return false; }

  if (!mobile) { alert("Mobile number must be entered"); return false; }
  if (!mobileRegex.test(mobile)) { alert("Mobile number must be in format XXX-XXX-XXXX"); return false; }

  if (!dob) { alert("DOB must be entered"); return false; }
  if (!dobRegex.test(dob)) { alert("DOB must be in format DD-MM-YYYY"); return false; }

  if (!email) { alert("Email must be entered"); return false; }
  if (!emailRegex.test(email)) { alert("Enter a valid email address"); return false; }

  alert("Form submitted successfully!");
  return true;
}
