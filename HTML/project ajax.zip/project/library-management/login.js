function submitLogin() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const errorDiv = document.getElementById("loginError");
  errorDiv.textContent = "";

  // c) AJAX login check
  ajaxLogin(email, password, function (result) {
    if (result.success) {
      sessionStorage.setItem("loggedInUser", JSON.stringify(result.user));
      window.location.href = "home.html";
    } else {
      errorDiv.textContent = result.message; // "Invalid Credentials"
    }
  });
}
