const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

// b) validate email pattern first, then check existence via AJAX
function checkEmail() {
  const email = document.getElementById("email").value.trim();
  const msg = document.getElementById("emailMsg");
  msg.textContent = "";

  if (email === "") return;

  if (!emailRegex.test(email)) {
    msg.textContent = "Invalid email-id";
    return;
  }

  // a) AJAX call to check if email already exists
  ajaxCheckEmailExists(email, function (exists) {
    msg.textContent = exists ? "Email already exists!" : "";
  });
}

function submitRegistration() {
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const dob = document.getElementById("dob").value;
  const gender = document.getElementById("gender").value;
  const occupation = document.getElementById("occupation").value.trim();
  const city = document.getElementById("city").value.trim();
  const mobile = document.getElementById("mobile").value.trim();
  const msg = document.getElementById("emailMsg");

  if (!emailRegex.test(email)) {
    msg.textContent = "Invalid email-id";
    return;
  }

  const profile = {
    email: email,
    password: password,
    name: name,
    dob: dob,
    gender: gender,
    occupation: occupation,
    city: city,
    mobile: mobile
  };

  // c) On successful registration -> go to Login page
  ajaxRegisterUser(profile, function (result) {
    if (result.success) {
      alert("Registration successful! Please login.");
      window.location.href = "login.html";
    } else {
      msg.textContent = result.message; // "Email already exists!"
    }
  });
}
