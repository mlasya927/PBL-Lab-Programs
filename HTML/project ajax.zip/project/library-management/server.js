/*
  server.js
  ---------
  Simulates a backend using localStorage as the "database".
  All functions mimic AJAX calls (async, with a small delay) so the
  register/login pages behave like they are talking to a real server.
  Replace these with real fetch()/XMLHttpRequest calls to your servlet
  when you have an actual backend.
*/

const DB_KEY = "xyz_library_profiles";

function getProfiles() {
  return JSON.parse(localStorage.getItem(DB_KEY) || "[]");
}

function saveProfiles(profiles) {
  localStorage.setItem(DB_KEY, JSON.stringify(profiles));
}

// Simulated AJAX: check if email already exists
function ajaxCheckEmailExists(email, callback) {
  setTimeout(function () {
    const profiles = getProfiles();
    const exists = profiles.some(function (p) {
      return p.email.toLowerCase() === email.toLowerCase();
    });
    callback(exists);
  }, 300);
}

// Simulated AJAX: register a new user
function ajaxRegisterUser(profile, callback) {
  setTimeout(function () {
    const profiles = getProfiles();
    const exists = profiles.some(function (p) {
      return p.email.toLowerCase() === profile.email.toLowerCase();
    });
    if (exists) {
      callback({ success: false, message: "Email already exists!" });
      return;
    }
    profiles.push(profile);
    saveProfiles(profiles);
    callback({ success: true });
  }, 300);
}

// Simulated AJAX: login
function ajaxLogin(email, password, callback) {
  setTimeout(function () {
    const profiles = getProfiles();
    const user = profiles.find(function (p) {
      return p.email.toLowerCase() === email.toLowerCase() && p.password === password;
    });
    if (user) {
      callback({ success: true, user: user });
    } else {
      callback({ success: false, message: "Invalid Credentials" });
    }
  }, 300);
}
