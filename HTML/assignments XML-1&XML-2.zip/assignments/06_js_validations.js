function validateMember() {
  const memno = document.getElementById("memno");
  const pwd = document.getElementById("mempwd");

  if (memno.value.trim() === "") { alert("Member number must be entered"); memno.focus(); return false; }
  if (isNaN(memno.value)) { alert("Member number must be a number"); memno.focus(); return false; }
  if (pwd.value.trim() === "") { alert("Password must be entered"); pwd.focus(); return false; }
  if (pwd.value.length <= 4) { alert("Password must be longer than 4 characters"); pwd.focus(); return false; }

  return true;
}

function validatePhone() {
  const phone = document.getElementById("phone");
  const regex = /^(\d{3}-\d{3}-\d{4}|\d{3}\.\d{3}\.\d{4}|\d{3} \d{3} \d{4})$/;

  if (phone.value.trim() === "") { alert("Phone number must be entered"); phone.focus(); return false; }
  if (!regex.test(phone.value)) { alert("Phone number must be in format XXX-XXX-XXXX"); phone.focus(); return false; }

  return true;
}

function validateStrongPwd() {
  const pwd = document.getElementById("strongpwd");
  const regex = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9]{6,20}$/;

  if (!regex.test(pwd.value)) {
    alert("Password must be 6-20 chars with at least one number, one uppercase and one lowercase letter");
    pwd.focus();
    return false;
  }
  return true;
}
