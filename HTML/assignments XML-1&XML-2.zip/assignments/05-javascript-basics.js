// Ex 1: HelloWorld
document.getElementById("hello").innerHTML = "HelloWorld";

// Ex 2: reverse a number
function reverseNumber(x) {
  return parseInt(String(x).split("").reverse().join(""));
}
document.getElementById("reverseOut").innerHTML =
  "reverseNumber(32243) = " + reverseNumber(32243);

// Ex 3: palindrome check
function checkPalindrome() {
  const str = document.getElementById("palText").value;
  const clean = str.toLowerCase().replace(/[^a-z0-9]/g, "");
  const reversed = clean.split("").reverse().join("");
  document.getElementById("palOut").innerHTML =
    clean === reversed ? "Yes, it's a palindrome" : "No, not a palindrome";
}

// Ex 4: capitalize first letter of each word
function capitalizeWords() {
  const str = document.getElementById("capText").value;
  const result = str.replace(/\b\w/g, function (c) {
    return c.toUpperCase();
  });
  document.getElementById("capOut").innerHTML = result;
}

// Ex 5: position of first occurrence of "World"
const txt = "Hello World, welcome to the World of JavaScript";
document.getElementById("posOut").innerHTML =
  'Position of "World" in: "' + txt + '" is ' + txt.indexOf("World");

// Ex 6: convert text to upper case
const sampleText = "convert this text to upper case";
document.getElementById("upperOut").innerHTML = sampleText.toUpperCase();

// Ex 7: remove specified number of characters
function removeChars() {
  const str = document.getElementById("remText").value;
  const n = parseInt(document.getElementById("remCount").value) || 0;
  document.getElementById("remOut").innerHTML = str.slice(0, str.length - n);
}

// Ex 8: calculate sum, alert
function calculateSum() {
  const n1 = parseFloat(document.getElementById("num1").value) || 0;
  const n2 = parseFloat(document.getElementById("num2").value) || 0;
  alert("Sum = " + (n1 + n2));
}

// Ex 9: transform input to uppercase on blur
document.getElementById("blurUpperInput").addEventListener("blur", function () {
  this.value = this.value.toUpperCase();
});

// Ex 10: change background color based on link clicked
function changeBg(color) {
  document.body.style.backgroundColor = color;
}

// Ex 11a: today's date alert
function todayAlert() {
  alert("Today's date: " + new Date().toDateString());
}
// Ex 11b: greet user
function greetUser() {
  const name = prompt("Please enter your name:");
  if (name) alert("Hello " + name);
}
// Ex 11c: sum via prompt
function promptSum() {
  const a = parseFloat(prompt("Enter first number:")) || 0;
  const b = parseFloat(prompt("Enter second number:")) || 0;
  alert("Sum = " + (a + b));
}

// Ex 12: odd or even
function checkOddEven() {
  const num = parseInt(document.getElementById("oddEvenInput").value);
  document.getElementById("oddEvenOut").innerHTML =
    num % 2 === 0 ? num + " is Even" : num + " is Odd";
}

// Ex 13: dynamic clock HH:MM:SS using setTimeout
function startClock() {
  const clockEl = document.getElementById("clock");
  function tick() {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    const ss = String(now.getSeconds()).padStart(2, "0");
    clockEl.value = hh + ":" + mm + ":" + ss;
    setTimeout(tick, 1000);
  }
  tick();
}
