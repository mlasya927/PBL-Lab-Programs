document.write("HelloWorld");

function reverseNumber(x) {
  return x.toString().split('').reverse().join('');
}
document.getElementById("rev").innerText = reverseNumber(32243);

function isPalindrome(str) {
  const rev = str.split('').reverse().join('');
  return str === rev;
}
document.getElementById("pal").innerText = isPalindrome("madam");

function capitalizeWords(str) {
  return str.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}
document.getElementById("cap").innerText = capitalizeWords("hello world js");

const txt = "Hello World";
document.getElementById("pos").innerText = txt.indexOf("World");

document.getElementById("upper").innerText = "hello".toUpperCase();

function removeChars(str, n) {
  return str.slice(0, str.length - n);
}
document.getElementById("removed").innerText = removeChars("JavaScript", 3);

function calcSum() {
  const n1 = Number(document.getElementById("n1").value);
  const n2 = Number(document.getElementById("n2").value);
  alert("Sum: " + (n1 + n2));
}

function toUpper() {
  const el = document.getElementById("uctext");
  el.value = el.value.toUpperCase();
}

function setBg(color) {
  document.body.style.backgroundColor = color;
}

function checkOddEven() {
  const num = Number(prompt("Enter a number:"));
  alert(num % 2 === 0 ? "Even" : "Odd");
}

// today's date, name prompt, sum prompt (Q11)
alert("Today's date: " + new Date().toDateString());
const uname = prompt("Enter your name:");
alert("Hello " + uname);
const a = Number(prompt("Enter first number:"));
const b = Number(prompt("Enter second number:"));
alert("Sum: " + (a + b));

// live clock in textbox (Q13)
function updateClockBox() {
  const now = new Date();
  document.getElementById("clockbox").value = now.toLocaleTimeString();
  setTimeout(updateClockBox, 1000);
}
window.onload = updateClockBox;
