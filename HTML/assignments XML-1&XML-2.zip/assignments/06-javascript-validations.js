// Ex 3: strong password check helper
// must be 6-20 chars, at least 1 digit, 1 uppercase, 1 lowercase
function isStrongPassword(pwd) {
  if (pwd.length < 6 || pwd.length > 20) return false;
  if (!/[0-9]/.test(pwd)) return false;
  if (!/[A-Z]/.test(pwd)) return false;
  if (!/[a-z]/.test(pwd)) return false;
  return true;
}

function validateMemberForm() {
  const memberNo = document.forms["memberForm"]["memberNo"];
  const pwd = document.forms["memberForm"]["pwd"];
  const phone = document.forms["memberForm"]["phone"];

  const phoneRegex = /^(\d{3}-\d{3}-\d{4}|\d{3}\.\d{3}\.\d{4}|\d{3} \d{3} \d{4})$/;

  // Ex 1: Member number
  if (memberNo.value.trim() === "") {
    alert("Member number must be entered");
    memberNo.focus();
    return false;
  }
  if (isNaN(memberNo.value)) {
    alert("Member number must be a number");
    memberNo.focus();
    return false;
  }

  // Ex 1: Password (must be entered, > 4 chars)
  if (pwd.value === "") {
    alert("Password must be entered");
    pwd.focus();
    return false;
  }
  if (pwd.value.length <= 4) {
    alert("Password must be longer than 4 characters");
    pwd.focus();
    return false;
  }

  // Ex 3: strong password rule (digit, upper, lower, 6-20 chars)
  if (!isStrongPassword(pwd.value)) {
    alert("Password must be 6-20 characters and contain at least one digit, one uppercase and one lowercase letter");
    pwd.focus();
    return false;
  }

  // Ex 2: Phone Number
  if (phone.value.trim() === "") {
    alert("Phone Number must be entered");
    phone.focus();
    return false;
  }
  if (!phoneRegex.test(phone.value.trim())) {
    alert("Phone Number must be in format XXX-XXX-XXXX or XXX.XXX.XXXX or XXX XXX XXXX");
    phone.focus();
    return false;
  }

  alert("All fields valid. Form submitted!");
  return true;
}
