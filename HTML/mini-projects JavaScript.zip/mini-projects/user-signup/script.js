// Show current date and time at top-right corner, updates every second
function showDateTime() {
  const el = document.getElementById("datetime");
  function update() {
    const now = new Date();
    el.textContent = now.toLocaleDateString() + " " + now.toLocaleTimeString();
  }
  update();
  setInterval(update, 1000);
}

// 3-minute timer: alert if the user takes more than 3 mins to fill the form
window.addEventListener("load", function () {
  setTimeout(function () {
    alert("3 mins past. Please complete the form soon.");
  }, 3 * 60 * 1000);
});

function validateForm() {
  const fname = document.forms["signupForm"]["fname"].value.trim();
  const lname = document.forms["signupForm"]["lname"].value.trim();
  const pwd = document.forms["signupForm"]["pwd"].value;
  const cpwd = document.forms["signupForm"]["cpwd"].value;
  const gender = document.forms["signupForm"]["gender"];
  const mobile = document.forms["signupForm"]["mobile"].value.trim();
  const dob = document.forms["signupForm"]["dob"].value.trim();
  const email = document.forms["signupForm"]["email"].value.trim();

  const nameRegex = /^[A-Za-z]+$/;
  const mobileRegex = /^(\d{3}-\d{3}-\d{4}|\d{3}\.\d{3}\.\d{4}|\d{3} \d{3} \d{4})$/;
  const dobRegex = /^\d{2}-\d{2}-\d{4}$/;
  const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

  // First Name
  if (fname === "") {
    alert("First Name must be entered");
    document.forms["signupForm"]["fname"].focus();
    return false;
  }
  if (!nameRegex.test(fname)) {
    alert("First Name must be character");
    document.forms["signupForm"]["fname"].focus();
    return false;
  }

  // Last Name
  if (lname === "") {
    alert("Last Name must be entered");
    document.forms["signupForm"]["lname"].focus();
    return false;
  }
  if (!nameRegex.test(lname)) {
    alert("Last Name must be character");
    document.forms["signupForm"]["lname"].focus();
    return false;
  }

  // Password
  if (pwd === "") {
    alert("Password must be entered");
    document.forms["signupForm"]["pwd"].focus();
    return false;
  }
  if (pwd.length < 6 || pwd.length > 20) {
    alert("Password length should be between 6 to 20 characters");
    document.forms["signupForm"]["pwd"].focus();
    return false;
  }

  // Confirm Password
  if (cpwd === "") {
    alert("Confirm Password must be entered");
    document.forms["signupForm"]["cpwd"].focus();
    return false;
  }
  if (cpwd.length < 6 || cpwd.length > 20) {
    alert("Confirm Password length should be between 6 to 20 characters");
    document.forms["signupForm"]["cpwd"].focus();
    return false;
  }
  if (pwd !== cpwd) {
    alert("Password and Confirm Password should be same");
    document.forms["signupForm"]["cpwd"].focus();
    return false;
  }

  // Gender
  let genderSelected = false;
  for (let i = 0; i < gender.length; i++) {
    if (gender[i].checked) genderSelected = true;
  }
  if (!genderSelected) {
    alert("Gender must be selected");
    return false;
  }

  // Mobile Number
  if (mobile === "") {
    alert("Mobile Number must be entered");
    document.forms["signupForm"]["mobile"].focus();
    return false;
  }
  if (!mobileRegex.test(mobile)) {
    alert("Mobile Number must be in format XXX-XXX-XXXX or XXX.XXX.XXXX or XXX XXX XXXX");
    document.forms["signupForm"]["mobile"].focus();
    return false;
  }

  // DOB
  if (dob === "") {
    alert("DOB must be entered");
    document.forms["signupForm"]["dob"].focus();
    return false;
  }
  if (!dobRegex.test(dob)) {
    alert("DOB must be in format DD-MM-YYYY");
    document.forms["signupForm"]["dob"].focus();
    return false;
  }

  // Email
  if (email === "") {
    alert("Email Address must be entered");
    document.forms["signupForm"]["email"].focus();
    return false;
  }
  if (!emailRegex.test(email)) {
    alert("Enter a valid email address (must contain @ and a dot, with a character after @ before the dot, and a character after the dot)");
    document.forms["signupForm"]["email"].focus();
    return false;
  }

  alert("Form submitted successfully!");
  return true;
}
