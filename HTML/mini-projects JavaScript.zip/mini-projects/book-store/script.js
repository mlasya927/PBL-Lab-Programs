document.querySelectorAll(".action-btn").forEach(function (btn) {
  btn.addEventListener("click", function () {
    alert(btn.textContent.trim() + " clicked");
  });
});
